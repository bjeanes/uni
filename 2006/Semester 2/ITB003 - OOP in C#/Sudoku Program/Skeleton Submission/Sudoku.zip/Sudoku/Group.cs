using System;
using System.Collections.Generic;
using System.Text;

namespace Sudoku
{
    class Group
    {
        private Square[] squares;
        private int numSquares;

        public Group()
        {
        }

        public void AddSquare(Square square)
        {
            // if all ok, increment numSquares
        }

        public bool Check()
        {
            // REMOVE LATER:
            return true;
        }
    }
}
