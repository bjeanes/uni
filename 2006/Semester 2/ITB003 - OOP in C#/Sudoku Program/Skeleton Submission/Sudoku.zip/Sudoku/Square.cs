using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sudoku
{
    abstract class Square
    {
        private int row;
        private int column;
        protected int correctAnswer;
        protected Button button;
        protected Puzzle puzzle;

        public Square(Puzzle puzzle, int Row, int Column, int answer)
        {
        }

        public Button Button
        {
            get
            {
                return button;
            }
        }

        public virtual void InitButton()
        {
        }

        public abstract bool HasNumber(int num);

        public abstract bool IsSingleNumber();

        public abstract int GetSingleNumber();

        public abstract bool CheckAnswer(bool finished);

        public abstract bool Check(Square square);

        public abstract void Error();

        public abstract void ShowAnswer();
    }
}
