using System;
using System.Collections.Generic;
using System.Text;

namespace Sudoku
{
    class Puzzle
    {
        private Square[][] puzzle;
        private Group[] rows;
        private Group[] columns;
        private Group[] blocks;
        private Game game;
        private String puzzleString;

        public Puzzle(Game game, String puzzle)
        {
        }

        public void Clear()
        {
        }

        public String PuzzleString
        {
            get
            {
                return puzzleString;
            }
            set
            {
                puzzleString = value;
            }
        }

        public void Load(Game game)
        {
        }

        public void CheckValues()
        {
        }

        public void CheckFinished()
        {
        }

        public void SetCurrent(UserSquare square)
        {
        }

        public bool IsFinished()
        {
            // REMOVE LATER:
            return true;
        }

        public void ShowSolution()
        {
        }
    }
}
