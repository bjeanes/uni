using System;
using System.Collections.Generic;
using System.Text;

namespace Sudoku
{
    class UserSquare : Square
    {
        private int[] numbers;
        private bool checkMode;

        public UserSquare(Puzzle puzzle, int row, int column, int answer) : base(puzzle, row, column, answer)
        {
        }

        public override void InitButton()
        {
        }

        public override bool HasNumber(int num)
        {
            // REMOVE LATER:
            return true;
        }

        public override bool IsSingleNumber()
        {
            // REMOVE LATER:
            return true;
        }

        public override int GetSingleNumber()
        {
            // REMOVE LATER:
            return 0;
        }

        public void AddNumber(int num)
        {
        }

        public void RemoveNumber(int num)
        {
        }

        public void Clear()
        {
        }

        public override bool CheckAnswer(bool finished)
        {
            // REMOVE LATER:
            return true;
        }

        public override bool Check(Square square)
        {
            // REMOVE LATER:
            return true;
        }

        public override void Error()
        {
        }

        public override void ShowAnswer()
        {
        }

        public void Unselect()
        {
        }

        public void ResetCheckMode()
        {
        }

        public void ButtonClick(object sender, EventArgs args)
        {
        }
    }
}