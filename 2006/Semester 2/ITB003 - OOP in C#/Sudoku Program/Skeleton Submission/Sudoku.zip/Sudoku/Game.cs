using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sudoku
{
    enum DifficultyLevel
    {
        easy,
        medium,
        hard,
        genius
    }

    class Game
    {
        private Puzzle currentPuzzle;
        private UserSquare currentSquare;
        private GroupBox grid; 
        private String[] morePuzzles; // one element per line of save file (excluding first)
        private int puzzlesAvailable; // first line of save file

        public Game(GroupBox grid)
        {
        }

        public void NewPuzzle(DifficultyLevel level)
        {
        }

        public bool PuzzlesAvailable()
        {
            // REMOVE LATER:
            return true;
        }

        public GroupBox GetGrid()
        {
            return null;
        }
        
        public void ReadPuzzles(String filename)
        {
        }

        public UserSquare CurrentSquare
        { 
            get 
            {
                return currentSquare;
            }
            set
            {
                currentSquare = value;
            }
        }

        public void AddNumber(int num)
        {
        }

        public void RemoveNumber(int num)
        {
        }

        public void ClearCurrentSquare()
        {
        }

        public void Clear()
        {
        }

        public void Checkvalues()
        {
        }

        public bool CheckFinished()
        {
            // REMOVE LATER:
            return true;
        }

        public void GiveHint()
        {
        }

        public bool PuzzleFinised()
        {
            // REMOVE LATER:
            return true;
        }
        
        public void ShowSolution()
        {
        }

        public void SavePuzzles(bool saveCurrentGame)
        {
        }

        public bool LoadPuzzle()
        {
            // REMOVE LATER:
            return true;
        }

        public bool SavePuzzle()
        {
            // REMOVE LATER:
            return true;
        }
    }
}
