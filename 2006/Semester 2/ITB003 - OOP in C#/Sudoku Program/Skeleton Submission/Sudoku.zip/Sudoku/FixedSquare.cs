using System;
using System.Collections.Generic;
using System.Text;

namespace Sudoku
{
    class FixedSquare : Square
    {
        public FixedSquare(Puzzle puzzle, int row, int column, int answer) : base(puzzle,row,column,answer)
        {
        }

        public override void InitButton()
        {
        }

        public override bool HasNumber(int num)
        {
            // REMOVE LATER:
            return true;
        }

        public override bool IsSingleNumber()
        {
            // REMOVE LATER:
            return true;
        }

        public override int GetSingleNumber()
        {
            // REMOVE LATER:
            return 0;
        }

        public override bool CheckAnswer(bool finished)
        {
            // REMOVE LATER:
            return true;
        }

        public override bool Check(Square square)
        {
            // REMOVE LATER:
            return true;
        }

        public override void Error()
        {
        }

        public override void ShowAnswer()
        {
        }
    }
}